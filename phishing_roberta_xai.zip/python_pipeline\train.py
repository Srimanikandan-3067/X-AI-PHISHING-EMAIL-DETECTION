# ==============================================================================
# PyTorch & Hugging Face RoBERTa Fine-Tuning Pipeline for Phishing Email Detection
# ==============================================================================
import os
import torch
import torch.nn as nn
from transformers import (
    RobertaTokenizer, 
    RobertaForSequenceClassification, 
    Trainer, 
    TrainingArguments
)
from datasets import load_dataset
import numpy as np
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, roc_auc_score

def compute_metrics(eval_pred):
    """
    Computes classification performance metrics: Accuracy, F1-score, Precision, Recall, and ROC-AUC.
    """
    logits, labels = eval_pred
    preds = np.argmax(logits, axis=1)
    probs = torch.softmax(torch.tensor(logits), dim=1)[:, 1].numpy()
    
    precision, recall, f1, _ = precision_recall_fscore_support(labels, preds, average='binary')
    acc = accuracy_score(labels, preds)
    auc = roc_auc_score(labels, probs)
    return {
        "accuracy": float(acc), 
        "f1": float(f1), 
        "precision": float(precision), 
        "recall": float(recall), 
        "auc": float(auc)
    }

def train_roberta_phishing_model():
    print("=" * 80)
    print("Starting RoBERTa Fine-Tuning Pipeline for Phishing Email Detection")
    print("=" * 80)

    model_name = "roberta-base"
    print(f"Loading pretrained tokenizer and model: {model_name}")
    tokenizer = RobertaTokenizer.from_pretrained(model_name)
    model = RobertaForSequenceClassification.from_pretrained(model_name, num_labels=2)

    # Check for GPU acceleration
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using compute device: {device}")
    model.to(device)

    # Hyperparameters
    MAX_LENGTH = 512
    BATCH_SIZE = 16
    EPOCHS = 4
    LEARNING_RATE = 2e-5

    print(f"Hyperparameters: Max Length={MAX_LENGTH}, Batch Size={BATCH_SIZE}, Epochs={EPOCHS}, LR={LEARNING_RATE}")

    # Data Tokenization function
    def tokenize_function(examples):
        return tokenizer(examples["text"], padding="max_length", truncation=True, max_length=MAX_LENGTH)

    # Output Checkpoints Directory
    output_dir = "./roberta_phishing_checkpoints"
    os.makedirs(output_dir, exist_ok=True)

    training_args = TrainingArguments(
        output_dir=output_dir,
        eval_strategy="epoch" if hasattr(TrainingArguments, 'eval_strategy') else "evaluation_strategy",
        save_strategy="epoch",
        learning_rate=LEARNING_RATE,
        per_device_train_batch_size=BATCH_SIZE,
        per_device_eval_batch_size=BATCH_SIZE * 2,
        num_train_epochs=EPOCHS,
        weight_decay=0.01,
        fp16=torch.cuda.is_available(),
        logging_steps=50,
        load_best_model_at_end=True,
        metric_for_best_model="f1"
    )

    print("Pipeline ready. (To run training on custom JSON data, specify datasets path).")
    print("Pipeline script initialized successfully.")

if __name__ == "__main__":
    train_roberta_phishing_model()
