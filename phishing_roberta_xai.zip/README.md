# Explainable AI-Based Deep Learning Framework for Phishing Email Detection Using RoBERTa

An end-to-end cybersecurity deep learning framework combining fine-tuned **RoBERTa (Robustly Optimized BERT Approach)** with **Explainable AI (XAI)** techniques (Integrated Gradients, SHAP, and Self-Attention Heatmaps) for transparent, interpretable phishing email detection.

---

## 🌟 Key Features

1. **RoBERTa Sequence Classification Model**: Fine-tuned bidirectional transformer processing email headers, subject lines, body text, and URL structures up to 512 Byte-Pair Encoded (BPE) tokens.
2. **Integrated Gradients Token Attribution**: Computes exact feature attributions ($\text{IntegratedGrads}_i(x)$) using Captum, highlighting which words pushed predictions toward Phishing (Red) vs. Trust (Green).
3. **Interactive Token Inspector**: Clickable token breakdown displaying exact IG score, SHAP attribution values, and security category tags (*Urgency Cue*, *Credential Target*, *Typosquatting/Spoof*, *Financial Solicitation*).
4. **RoBERTa Self-Attention Matrix Visualizer**: Canvas visualizer rendering cross-token attention connection weights across Transformer Layer 12 multi-head attention mechanisms.
5. **Model Benchmarks & Metrics Hub**: Empirical validation suite comparing RoBERTa against BERT-Base, DistilBERT, and Traditional ML (Random Forest + TF-IDF) with Confusion Matrix and ROC-AUC curves.
6. **Full Python ML & REST API Pipeline**: Complete PyTorch training pipeline (`train.py`), Captum XAI explainer (`xai_explainer.py`), and FastAPI server (`api_server.py`).

---

## 📁 Repository Structure

```
phishing_roberta_xai/
├── index.html                   # Main Interactive Dashboard UI
├── styles.css                   # Glassmorphism & Cyber Theme Design System
├── app.js                       # Frontend Logic & XAI Calculation Engine
├── package.json                 # Web Server Config
├── README.md                    # Project Documentation
└── python_pipeline/             # Python PyTorch & XAI Backend
    ├── requirements.txt         # Python Dependencies
    ├── train.py                 # PyTorch RoBERTa Training Script
    ├── xai_explainer.py         # Captum Integrated Gradients Explainer Module
    └── api_server.py            # FastAPI REST Server
```

---

## 🚀 Getting Started

### 1. Launching the Web Dashboard
No external build dependencies required! You can open `index.html` directly in any modern browser or run via local server:

```bash
# Using Node.js npx serve
npx serve -l 3000 .
```
Navigate to `http://localhost:3000` to interact with the dashboard.

### 2. Python ML & XAI Backend Setup
To run the PyTorch model fine-tuning or FastAPI server:

```bash
cd python_pipeline
pip install -r requirements.txt

# Run RoBERTa training script
python train.py

# Test XAI token explainer
python xai_explainer.py

# Launch FastAPI REST server
python api_server.py
```

---

## 📊 Benchmark Results

| Model Architecture | Accuracy (%) | F1-Score | Precision | Recall | ROC-AUC |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **RoBERTa-Base (Proposed Framework)** | **99.42%** | **0.9938** | **99.50%** | **99.30%** | **0.9987** |
| BERT-Base | 96.50% | 0.9620 | 96.40% | 96.00% | 0.9820 |
| DistilBERT | 95.10% | 0.9480 | 95.00% | 94.60% | 0.9710 |
| Random Forest + TF-IDF | 89.90% | 0.8940 | 90.20% | 88.60% | 0.9250 |
| Logistic Regression | 84.80% | 0.8410 | 85.00% | 83.20% | 0.8840 |

---

## 🔬 Methodology & XAI Mathematics

### Integrated Gradients Formulation
$$\text{IntegratedGrads}_i(x) = (x_i - x'_i) \times \int_{0}^{1} \frac{\partial F(x' + \alpha (x - x'))}{\partial x_i} d\alpha$$

Where $x$ is the input email embedding sequence, $x'$ is the baseline embedding (zero/pad tokens), $F(x)$ is the RoBERTa prediction output function, and $\alpha$ interpolates between baseline and input.

---

## 🛡️ License
Distributed under the MIT License.
