# ==============================================================================
# FastAPI Production REST Server for RoBERTa Phishing XAI Inference
# ==============================================================================
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Optional
import torch

try:
    from xai_explainer import RoBERTaPhishingXAIExplainer
except ImportError:
    RoBERTaPhishingXAIExplainer = None

app = FastAPI(
    title="RoBERTa XAI Phishing Detection API",
    description="RESTful API delivering real-time predictions and Integrated Gradients token attributions.",
    version="1.0.0"
)

explainer = None

@app.on_event("startup")
def load_model():
    global explainer
    print("Initializing RoBERTa Model & Captum XAI Explainer...")
    if RoBERTaPhishingXAIExplainer:
        try:
            explainer = RoBERTaPhishingXAIExplainer()
            print("RoBERTa model initialized.")
        except Exception as e:
            print(f"Warning: Model startup deferred until weights available ({e})")

class EmailPayload(BaseModel):
    sender: str
    subject: str
    body: str
    include_attention: Optional[bool] = True

@app.get("/")
def read_root():
    return {
        "status": "online",
        "model": "RoBERTa-Base + Captum Integrated Gradients",
        "endpoints": ["/api/v1/analyze"]
    }

@app.post("/api/v1/analyze")
async def analyze_email(payload: EmailPayload):
    full_text = f"From: {payload.sender} | Subject: {payload.subject} | Body: {payload.body}"
    
    if explainer and explainer.model:
        try:
            inputs = explainer.tokenizer(full_text, return_tensors="pt", truncation=True, max_length=512).to(explainer.device)
            with torch.no_grad():
                outputs = explainer.model(**inputs)
                probs = torch.softmax(outputs.logits, dim=1)[0]
                phishing_prob = float(probs[1].item())

            xai_data = explainer.explain_email(full_text, target_class=1)

            verdict = "PHISHING" if phishing_prob > 0.5 else "LEGITIMATE"
            
            return {
                "verdict": verdict,
                "phishing_risk_score": round(phishing_prob * 100, 2),
                "confidence": round(float(probs.max().item()) * 100, 2),
                "token_attributions": xai_data["tokens"],
                "attention_matrix": xai_data["attention_matrix"] if payload.include_attention else None
            }
        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))
    else:
        # Fallback response for API demonstration
        return {
            "verdict": "PHISHING",
            "phishing_risk_score": 94.2,
            "confidence": 99.1,
            "note": "FastAPI XAI endpoint running in demo mode. Deploy pretrained PyTorch model checkpoint to enable live GPU forward pass."
        }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
