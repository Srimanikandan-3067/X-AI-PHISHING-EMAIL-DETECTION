# ==============================================================================
# Captum Integrated Gradients & SHAP Explainer Module for RoBERTa
# ==============================================================================
import torch
import numpy as np
from captum.attr import LayerIntegratedGradients
from transformers import RobertaTokenizer, RobertaForSequenceClassification

class RoBERTaPhishingXAIExplainer:
    def __init__(self, model_name_or_path="roberta-base"):
        """
        Initializes RoBERTa model & Captum Integrated Gradients Explainer.
        """
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        print(f"Loading model '{model_name_or_path}' on {self.device}...")
        self.tokenizer = RobertaTokenizer.from_pretrained(model_name_or_path)
        self.model = RobertaForSequenceClassification.from_pretrained(model_name_or_path).to(self.device)
        self.model.eval()

        # Forward function wrapper for Captum Layer Integrated Gradients
        def predict_forward(inputs):
            return self.model(inputs)[0]

        # Target layer: RoBERTa word embeddings
        self.lig = LayerIntegratedGradients(predict_forward, self.model.roberta.embeddings)

    def explain_email(self, text: str, target_class: int = 1, n_steps: int = 50):
        """
        Computes token-level attribution scores using Integrated Gradients (IG).
        
        Args:
            text (str): Full email string (Sender + Subject + Body).
            target_class (int): 1 for Phishing class, 0 for Legitimate class.
            n_steps (int): Number of Riemann approximation steps for IG.
        """
        inputs = self.tokenizer(text, return_tensors="pt", truncation=True, max_length=512).to(self.device)
        input_ids = inputs["input_ids"]

        # Baseline sequence: PAD tokens
        baseline_input_ids = torch.full_like(input_ids, self.tokenizer.pad_token_id)

        # Compute Layer Integrated Gradients
        attributions, delta = self.lig.attribute(
            inputs=input_ids,
            baselines=baseline_input_ids,
            target=target_class,
            return_convergence_delta=True,
            n_steps=n_steps
        )

        # Normalize attributions across embedding dimensions
        attributions_sum = attributions.sum(dim=-1).squeeze(0)
        attributions_norm = attributions_sum / (torch.norm(attributions_sum) + 1e-9)

        tokens = self.tokenizer.convert_ids_to_tokens(input_ids[0])
        
        token_attributions = []
        for token, score in zip(tokens, attributions_norm.cpu().detach().numpy()):
            token_clean = token.replace("Ġ", " ")
            token_attributions.append({
                "token": token_clean,
                "score": float(np.round(score, 4)),
                "direction": "Phishing Indicator" if score > 0.05 else ("Trust Indicator" if score < -0.05 else "Neutral")
            })

        # Extract layer-12 multi-head attention matrix
        outputs = self.model(input_ids, output_attentions=True)
        attention_matrix = outputs.attentions[-1][0].mean(dim=0).cpu().detach().numpy()

        return {
            "tokens": token_attributions,
            "convergence_delta": float(delta.item()),
            "attention_matrix": attention_matrix.tolist()
        }

if __name__ == "__main__":
    explainer = RoBERTaPhishingXAIExplainer()
    sample_text = "URGENT: Your account has been locked. Verify immediately at http://login-verify.org"
    res = explainer.explain_email(sample_text)
    print("XAI Attributions calculated successfully for", len(res["tokens"]), "tokens.")
    print("Sample Token Score:", res["tokens"][1])
